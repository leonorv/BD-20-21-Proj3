insert into regiao values(1, 'Norte', 3689000);
insert into regiao values(2, 'Centro', 2327000);
insert into regiao values(3, 'Lisboa', 2884000);
insert into regiao values(4, 'Alentejo', 760099);
insert into regiao values(5, 'Algarve', 451006);

insert into concelho values(1, 2, 'Abrantes', 35377);
insert into concelho values(2, 2, 'Águeda', 45992); 	
insert into concelho values(3, 3, 'Aguiar da Beira ', 4740);
insert into concelho values(4, 4, 'Alandroal', 5064); 	
insert into concelho values(5, 5, 'Albergaria-a-Velha', 24128); 
insert into concelho values(6, 5, 'Albufeira', 41123); 	
insert into concelho values(7, 4, 'Alcácer do Sal', 11712); 
insert into concelho values(8, 3, 'Alcanena', 12860); 	
insert into concelho values(9, 4, 'Alcobaça',  53641); 	
insert into concelho values(10, 2, 'Alcochete', 244);
insert into concelho values(11, 2, 'Alenquer', 43596);
insert into concelho values(12, 2, 'Alfândega da Fé', 4568);
insert into concelho values(13, 2, 'Alijó', 10703);
insert into concelho values(14, 3, 'Aljezur', 5599);	
insert into concelho values(15, 4, 'Aljustrel', 8285);	
insert into concelho values(16, 3, 'Almada', 168987);
insert into concelho values(17, 5, 'Almeida', 5926); 	
insert into concelho values(18, 5, 'Almeirim', 22569);
insert into concelho values(19, 4, 'Almodôvar', 6746);
insert into concelho values(20, 3, 'Alpiarça', 7087); 	
insert into concelho values(21, 2, 'Alter do Chão', 319);
insert into concelho values(22, 1, 'Alvaiázere', 6626);
insert into concelho values(23, 3, 'Alvito', 2462);
insert into concelho values(24, 3, 'Amadora', 181724);
insert into concelho values(25, 1, 'Amarante', 56264);
insert into concelho values(26, 1, 'Amares', 18889);
insert into concelho values(27, 1, 'Anadia', 29150);
insert into concelho values(28, 2, 'Ansião', 13128);
insert into concelho values(29, 2, 'Arcos de Valdevez', 22847);
insert into concelho values(30, 2, 'Arganil', 12145);
insert into concelho values(31, 2, 'Armamar', 6297);
insert into concelho values(32, 2, 'Arouca', 22359);
insert into concelho values(33, 2, 'Arraiolos', 7363);
insert into concelho values(34, 2, 'Arronches', 3165);
insert into concelho values(35, 2, 'Arruda dos Vinhos', 13391);
insert into concelho values(36, 2, 'Aveiro', 78450);
insert into concelho values(37, 2, 'Avis', 4249);
insert into concelho values(38, 2, 'Azambuja', 21814);
insert into concelho values(39, 2, 'Baião', 20522);
insert into concelho values(40, 2, 'Barcelos', 120391);
insert into concelho values(41, 2, 'Barrancos', 1834);
insert into concelho values(42, 2, 'Barreiro', 78764);
insert into concelho values(43, 4, 'Batalha', 15805);
insert into concelho values(44, 4, 'Beja', 35854);
insert into concelho values(45, 4, 'Belmonte', 6859);
insert into concelho values(46, 4, 'Benavente', 29019);
insert into concelho values(47, 4, 'Bombarral', 13193);
insert into concelho values(48, 4, 'Borba', 7333);
insert into concelho values(49, 4, 'Boticas', 5750);
insert into concelho values(50, 4, 'Braga', 181494);
insert into concelho values(51, 4, 'Bragança', 35341);
insert into concelho values(52, 4, 'Cabeceiras de Basto', 16710);
insert into concelho values(53, 4, 'Cadaval', 14228);
insert into concelho values(54, 4, 'Caldas da Rainha', 51729);
insert into concelho values(55, 4, 'Caminha', 16684);
insert into concelho values(56, 4, 'Campo Maior', 8456);
insert into concelho values(57, 4, 'Cantanhede', 36595);
insert into concelho values(58, 4, 'Carrazeda de Ansiães', 6373);
insert into concelho values(59, 4, 'Carregal do Sal', 9835);
insert into concelho values(60, 4, 'Cartaxo', 24462);
insert into concelho values(61, 4, 'Cascais', 206479);
insert into concelho values(62, 4, 'Castanheira de Pera', 3191);
insert into concelho values(63, 4, 'Castelo Branco', 56109);
insert into concelho values(64, 4, 'Castelo de Paiva', 16733);
insert into concelho values(65, 4, 'Castelo de Vide', 3407);
insert into concelho values(66, 4, 'Castro Daire', 13928);
insert into concelho values(67, 4, 'Castro Marim', 6274);
insert into concelho values(68, 4, 'Castro Verde', 6946);
insert into concelho values(69, 5, 'Celorico da Beira', 6978);
insert into concelho values(70, 5, 'Celorico de Basto', 20098);	
insert into concelho values(71, 5, 'Chamusca', 9253);
insert into concelho values(72, 5, 'Chaves', 39345);
insert into concelho values(73, 5, 'Cinfães', 20427);
insert into concelho values(74, 5, 'Coimbra', 133724);
insert into concelho values(75, 5, 'Condeixa-a-Nova', 17597);
insert into concelho values(76, 5, 'Constância', 4002);
insert into concelho values(77, 5, 'Coruche', 17629);
insert into concelho values(78, 5, 'Covilhã', 7127);
insert into concelho values(79, 5, 'Crato', 3185);
insert into concelho values(80, 5, 'Cuba', 4599);
insert into concelho values(81, 5, 'Elvas', 20706);
insert into concelho values(82, 5, 'Entroncamento', 21214);
insert into concelho values(83, 5, 'Espinho', 29484);
insert into concelho values(84, 5, 'Esposende', 34057);
insert into concelho values(85, 4, 'Estarreja', 25965);
insert into concelho values(86, 4, 'Estremoz', 12816);
insert into concelho values(87, 4, 'Évora', 56596);
insert into concelho values(88, 4, 'Fafe', 48271);
insert into concelho values(89, 4, 'Faro', 60974);
insert into concelho values(90, 4, 'Felgueiras', 56576);
insert into concelho values(91, 4, 'Ferreira do Alentejo', 7848);
insert into concelho values(92, 4, 'Ferreira do Zêzere', 8619);
insert into concelho values(93, 4, 'Figueira da Foz', 62125);
insert into concelho values(94, 4, 'Figueira de Castelo Rodrigo', 5652);
insert into concelho values(95, 4, 'Figueiró dos Vinhos', 6169);
insert into concelho values(96, 4, 'Fornos de Algodres', 4989);
insert into concelho values(97, 4, 'Freixo de Espada à Cinta', 3780);
insert into concelho values(98, 4, 'Fronteira', 3410);
insert into concelho values(99, 4, 'Fundão', 26719);
insert into concelho values(100, 2, 'Gavião', 3347);
insert into concelho values(101, 2, 'Góis', 4260);
insert into concelho values(102, 2, 'Golegã', 5465);
insert into concelho values(103, 2, 'Gondomar', 168027);
insert into concelho values(104, 2, 'Gouveia', 14046);
insert into concelho values(105, 2, 'Grândola', 14826);
insert into concelho values(106, 2, 'Guarda', 42541);
insert into concelho values(107, 2, 'Guimarães', 158124);
insert into concelho values(108, 2, 'Idanha-a-Nova', 9716);
insert into concelho values(109, 2, 'Ílhavo', 38598);
insert into concelho values(110, 2, 'Lagoa', 22975);
insert into concelho values(111, 2, 'Lagos', 31049);
insert into concelho values(112, 1, 'Lamego', 26691);
insert into concelho values(113, 2, 'Leiria', 126897);
insert into concelho values(114, 3, 'Lisboa', 547733);
insert into concelho values(115, 2, 'Loulé', 70622);
insert into concelho values(116, 2, 'Loures', 205054);
insert into concelho values(117, 2, 'Lourinhã', 25735);
insert into concelho values(118, 2, 'Lousã', 17604);
insert into concelho values(119, 2, 'Lousada', 47387);
insert into concelho values(120, 2, 'Mação', 7338);
insert into concelho values(121, 2, 'Macedo de Cavaleiros', 15776);
insert into concelho values(122, 2, 'Mafra', 76685);
insert into concelho values(123, 2, 'Maia', 135306);
insert into concelho values(124, 2, 'Mangualde', 19880);
insert into concelho values(125, 2, 'Manteigas', 3430);
insert into concelho values(126, 2, 'Marco de Canaveses', 53450);
insert into concelho values(127, 2, 'Marinha Grande', 38681);
insert into concelho values(128, 2, 'Marvão', 3512);
insert into concelho values(129, 2, 'Matosinhos', 175478);
insert into concelho values(130, 3, 'Mealhada', 20428);
insert into concelho values(131, 3, 'Mêda', 5202);
insert into concelho values(132, 3, 'Melgaço', 9213);
insert into concelho values(133, 3, 'Mértola', 7274);
insert into concelho values(134, 3, 'Mesão Frio', 4433);
insert into concelho values(135, 3, 'Mira', 12465);
insert into concelho values(136, 3, 'Miranda do Corvo', 13098);
insert into concelho values(137, 3, 'Miranda do Douro', 7482);
insert into concelho values(138, 3, 'Mirandela', 23850);
insert into concelho values(139, 3, 'Mogadouro', 9542);
insert into concelho values(140, 3, 'Moimenta da Beira', 10212);
insert into concelho values(141, 3, 'Moita', 66029);
insert into concelho values(142, 3, 'Monção', 19230);
insert into concelho values(143, 3, 'Monchique', 6045);
insert into concelho values(144, 3, 'Mondim de Basto', 7493);
insert into concelho values(145, 3, 'Monforte', 3329);
insert into concelho values(146, 3, 'Montalegre', 10537);
insert into concelho values(147, 3, 'Montemor-o-Novo', 17437);
insert into concelho values(148, 3, 'Montemor-o-Velho', 26171);
insert into concelho values(149, 3, 'Montijo', 51222);
insert into concelho values(150, 3, 'Mora', 4978);
insert into concelho values(151, 3, 'Mortágua', 9607);
insert into concelho values(152, 3, 'Moura', 15167);
insert into concelho values(153, 3, 'Mourão', 2663);
insert into concelho values(154, 3, 'Murça', 5952);
insert into concelho values(155, 3, 'Murtosa', 10585);
insert into concelho values(156, 3, 'Nazaré', 15158);
insert into concelho values(157, 3, 'Nelas', 14037);
insert into concelho values(158, 3, 'Nisa', 7450);
insert into concelho values(159, 3, 'Óbidos', 11772);
insert into concelho values(160, 3, 'Odemira', 26066);
insert into concelho values(161, 3, 'Odivelas', 144549);
insert into concelho values(162, 3, 'Oeiras', 172120);
insert into concelho values(163, 3, 'Oleiros', 5721);
insert into concelho values(164, 3, 'Olhão', 45396);
insert into concelho values(165, 3, 'Oliveira de Azeméis', 68611);
insert into concelho values(166, 3, 'Oliveira de Frades', 10261);
insert into concelho values(167, 3, 'Oliveira do Hospital', 20855);
insert into concelho values(168, 3, 'Oliveira do Bairro', 23028);
insert into concelho values(169, 3, 'Ourém', 45932);
insert into concelho values(170, 3, 'Ourique', 5389);
insert into concelho values(171, 3, 'Ovar', 55398);
insert into concelho values(172, 3, 'Paços de Ferreira', 56709);
insert into concelho values(173, 3, 'Palmela', 64214);
insert into concelho values(174, 3, 'Pampilhosa da Serra', 4052);
insert into concelho values(175, 3, 'Paredes', 86072);
insert into concelho values(176, 3, 'Paredes de Coura', 8560);
insert into concelho values(177, 3, 'Pedrógão Grande', 3429);
insert into concelho values(178, 3, 'Penacova', 13812);
insert into concelho values(179, 3, 'Penafiel', 69922);	
insert into concelho values(180, 3, 'Penalva do Castelo', 7175);
insert into concelho values(181, 3, 'Penamacor', 4831);
insert into concelho values(182, 3, 'Penedono',  610);
insert into concelho values(183, 3, 'Penela', 5439);
insert into concelho values(184, 3, 'Peniche', 26487);
insert into concelho values(185, 3, 'Peso da Régua', 5830);
insert into concelho values(186, 3, 'Pinhel', 8607);
insert into concelho values(187, 3, 'Pombal', 51684);
insert into concelho values(188, 1, 'Ponte da Barca', 11210);
insert into concelho values(189, 1, 'Ponte de Lima', 41499);
insert into concelho values(190, 1, 'Ponte de Sor', 5092);
insert into concelho values(191, 1, 'Portalegre', 22359);
insert into concelho values(192, 1, 'Portel', 5870);
insert into concelho values(193, 1, 'Portimão', 55614);
insert into concelho values(194, 1, 'Porto', 215284);
insert into concelho values(195, 1, 'Porto de Mós', 23288);
insert into concelho values(196, 1, 'Póvoa de Lanhoso', 21886);
insert into concelho values(197, 1, 'Póvoa de Varzim', 63408);
insert into concelho values(198, 1, 'Proença-a-Nova', 8314);
insert into concelho values(199, 1, 'Redondo', 7031);
insert into concelho values(200, 1, 'Reguengos de Monsaraz', 10828);
insert into concelho values(201, 1, 'Resende', 11364);
insert into concelho values(202, 1, 'Ribeira de Pena', 6031);
insert into concelho values(203, 1, 'Rio Maior', 21192);
insert into concelho values(204, 1, 'Sabrosa', 6361);
insert into concelho values(205, 1, 'Sabugal', 12544);
insert into concelho values(206, 1, 'Salvaterra de Magos', 22159);
insert into concelho values(207, 1, 'Santa Comba Dão', 11597);
insert into concelho values(208, 1, 'Santa Maria da Feira', 139312);
insert into concelho values(209, 1, 'Santa Marta de Penaguião', 7356);
insert into concelho values(210, 1, 'Santarém', 62200);
insert into concelho values(211, 1, 'Santiago do Cacém', 29749);
insert into concelho values(212, 1, 'Santo Tirso', 71530);
insert into concelho values(213, 1, 'São Brás de Alportel', 10662);
insert into concelho values(214, 1, 'São João da Pesqueira', 7874);
insert into concelho values(215, 1, 'São João da Madeira', 21713);
insert into concelho values(216, 1, 'São Pedro do Sul', 16851);
insert into concelho values(217, 1, 'Sardoal', 3939);
insert into concelho values(218, 1, 'Sátão', 12444);
insert into concelho values(219, 1, 'Seia', 24702);
insert into concelho values(220, 1, 'Seixal',	158269);
insert into concelho values(221, 1, 'Sernancelhe', 5671);
insert into concelho values(222, 1, 'Serpa', 15623);
insert into concelho values(223, 1, 'Sertã', 15880);
insert into concelho values(224, 1, 'Sesimbra', 49500);
insert into concelho values(225, 1, 'Setúbal', 121185);
insert into concelho values(226, 1, 'Sever do Vouga', 12356);
insert into concelho values(227, 1, 'Silves', 37126);
insert into concelho values(228, 1, 'Sines', 14238);
insert into concelho values(229, 1, 'Sintra', 377835);
insert into concelho values(230, 1, 'Sobral de Monte Agraço',	10156);
insert into concelho values(231, 1, 'Soure', 19245);
insert into concelho values(232, 1, 'Sousel', 5074);
insert into concelho values(233, 1, 'Tábua', 12071);
insert into concelho values(234, 1, 'Tabuaço', 6350);
insert into concelho values(235, 1, 'Tarouca', 8048);
insert into concelho values(236, 1, 'Tavira', 26167);
insert into concelho values(237, 1, 'Terras de Bouro', 7253);
insert into concelho values(238, 1, 'Tomar', 40677);
insert into concelho values(239, 1, 'Tondela', 28946);
insert into concelho values(240, 1, 'Torre de Moncorvo', 8572);
insert into concelho values(241, 1, 'Torres Vedras', 79465);
insert into concelho values(242, 1, 'Torres Novas', 36717);
insert into concelho values(243, 1, 'Trancoso', 9878);
insert into concelho values(244, 1, 'Trofa', 38999);
insert into concelho values(245, 1, 'Vagos', 22851);
insert into concelho values(246, 1, 'Vale de Cambra',	22864);
insert into concelho values(247, 1, 'Valença', 14127);
insert into concelho values(248, 1, 'Valongo', 93858);
insert into concelho values(249, 1, 'Valpaços', 16882);
insert into concelho values(250, 1, 'Vendas Novas', 11846);
insert into concelho values(251, 1, 'Viana do Alentejo', 5743);
insert into concelho values(252, 1, 'Viana do Castelo', 88725);
insert into concelho values(253, 1, 'Vidigueira', 5932);
insert into concelho values(254, 1, 'Vieira do Minho', 12997);
insert into concelho values(255, 1, 'Vila do Conde', 79533);
insert into concelho values(256, 1, 'Vila de Rei', 3452);
insert into concelho values(257, 1, 'Vila do Bispo', 5258);
insert into concelho values(258, 1, 'Vila Flor', 6697);
insert into concelho values(259, 1, 'Vila Franca de Xira', 136886);
insert into concelho values(260, 1, 'Vila Nova da Barquinha', 7322);
insert into concelho values(261, 1, 'Vila Nova de Cerveira', 9253);
insert into concelho values(262, 1, 'Vila Nova de Poiares', 7281);
insert into concelho values(263, 1, 'Vila Nova de Famalicão', 133832);
insert into concelho values(264, 1, 'Vila Nova de Foz Côa', 7312);	
insert into concelho values(265, 1, 'Vila Nova de Gaia', 302295);
insert into concelho values(266, 1, 'Vila Nova de Paiva', 5176);
insert into concelho values(267, 1, 'Vila Pouca de Aguiar', 13187);
insert into concelho values(268, 1, 'Vila Real', 51850);
insert into concelho values(269, 1, 'Vila Real de Santo António', 19156);
insert into concelho values(270, 1, 'Vila Velha de Ródão', 3521);
insert into concelho values(271, 1, 'Vila Verde', 47888);
insert into concelho values(272, 1, 'Vila Viçosa', 8319);
insert into concelho values(273, 1, 'Vimioso', 4669);
insert into concelho values(274, 1, 'Vinhais', 9066);
insert into concelho values(275, 1, 'Viseu', 99274);
insert into concelho values(276, 1, 'Vizela',	23736);
insert into concelho values(277, 1, 'Vouzela', 10564);

insert into instituicao values('Casa Farmacêutica', 'farmacia', 32, 2); /*arouca*/
insert into instituicao values('Farmácia Nova Iorque', 'farmacia', 32, 2); /*arouca*/
insert into instituicao values('Farmácia da Luz', 'farmacia', 12, 2);
insert into instituicao values('Farmácia Decadente', 'farmacia', 55, 4);
insert into instituicao values('Farmácia Extremamente Decadente', 'farmacia', 100, 2);
insert into instituicao values('Farmácia de Jesus', 'farmacia', 45, 4);

insert into instituicao values('Laboratório de Santa Maria', 'laboratorio', 66, 4);
insert into instituicao values('Laboratório de São João', 'laboratorio', 14, 3);
insert into instituicao values('Centro Laboratorial da Cruz', 'laboratorio', 88, 4);
insert into instituicao values('Centro Laboratorial de Santa Maria', 'laboratorio', 88, 4);
insert into instituicao values('Isto Sim É Um Laboratório', 'laboratorio', 15, 4);
insert into instituicao values('Laboratório Razoável', 'laboratorio', 77, 5);

insert into instituicao values('Clínica Rio Verde', 'clinica', 203, 1);
insert into instituicao values('Clínica Muito Barata', 'clinica', 204, 1);
insert into instituicao values('Clínica Bonita', 'clinica', 205, 1);
insert into instituicao values('Clínica Rio Azul', 'clinica', 101, 2);
insert into instituicao values('Clínica de Preço Razoável', 'clinica', 102, 2);
insert into instituicao values('Clínica da Cooperativa', 'clinica', 103, 2);

insert into instituicao values('SAMS', 'hospital', 161, 3);
insert into instituicao values('Hospital Extremamente Caro', 'hospital', 162, 3);
insert into instituicao values('Hospital Ainda Mais Caro', 'hospital', 163, 3);
insert into instituicao values('Hospital Carérrimo', 'hospital', 18, 5);
insert into instituicao values('O Melhor Hospital que Existe', 'hospital', 17, 5);
insert into instituicao values('Centro Hospitalar Azul', 'hospital', 32, 2);
insert into instituicao values('Centro Hospitalar São Sebastião', 'hospital', 222, 1);
insert into instituicao values('Maternidade Alfredo da Costa', 'hospital', 20, 3);
insert into instituicao values('Hospital Incrível', 'hospital', 154, 3);

insert into medico values(1, 'Sancha Barroso', 'fisioterapia');
insert into medico values(2,'Balduíno Milheirão', 'fisioterapia');
insert into medico values(3,'Leonor Caniça', 'fisioterapia');
insert into medico values(4,'Bartira Leão', 'neurologia');
insert into medico values(5,'Pedro Ramos', 'neurologia');
insert into medico values(6, 'Duarte Valladares', 'neurologia');
insert into medico values(7, 'Célia Cerqueira', 'oftalmologia');
insert into medico values(8, 'Leonor Veloso', 'oftalmologia');
insert into medico values(9, 'Polibe Moita', 'cardiologia');
insert into medico values(10, 'Josefina Resende', 'cardiologia');
insert into medico values(11, 'Sandoval Girón', 'cardiologia');
insert into medico values(12, 'Marisa Frota', 'oncologia');
insert into medico values(13, 'Luciano Castelão', 'oncologia');
insert into medico values(14, 'César Seabra', 'ginecologia');
insert into medico values(15, 'Henrique Girón', 'urologia');
insert into medico values(16, 'Quintino Rebouças', 'pediatria');
insert into medico values(17, 'Romão Froes', 'pediatria');
insert into medico values(18, 'Alice Lins', 'radiologia');
insert into medico values(19, 'Minervina Paredes', 'radiologia');
insert into medico values(20, 'Vânia Guedelha', 'psiquiatria');
insert into medico values(21, 'Valério Antas', 'psiquiatria');
insert into medico values(22, 'Tairine Mora', 'psiquiatria');
insert into medico values(23, 'Martinho Afonso', 'medicina geral e familiar');

insert into consulta values(21, 1, '2020-8-21 15:11:18', 'Farmácia da Luz');
insert into consulta values(11, 3, '2020-7-24 13:10:11', 'O Melhor Hospital que Existe');
insert into consulta values( 8, 1, '2019-5-31 17:30:00', 'SAMS');
insert into consulta values( 4, 2, '2020-9-3 12:06:05', 'Hospital Carérrimo');
insert into consulta values(19, 5, '2020-10-30 14:15:00', 'SAMS');
insert into consulta values( 5, 5, '2019-01-01 10:15:00', 'Hospital Carérrimo');
insert into consulta values( 5, 4, '2020-11-03 12:06:05', 'Laboratório de São João');
insert into consulta values( 2, 4, '2020-07-22 12:12:12', 'Centro Hospitalar Azul');
insert into consulta values( 2, 5, '2020-07-06 12:12:12', 'Centro Hospitalar Azul');

insert into consulta values( 1, 1, '2019-01-17 15:11:18', 'Centro Hospitalar São Sebastião');
insert into consulta values( 1, 3, '2020-11-20 13:10:11', 'Centro Hospitalar São Sebastião');
insert into consulta values( 2, 1, '2019-11-20 17:30:00', 'Hospital Extremamente Caro');
insert into consulta values( 2, 2, '2020-11-20 12:06:05', 'Hospital Extremamente Caro');
insert into consulta values( 3, 10, '2020-11-23 14:15:00', 'Hospital Extremamente Caro');
insert into consulta values( 3, 5, '2020-11-24 10:15:00', 'Hospital Carérrimo');
insert into consulta values( 4, 6, '2020-11-25 12:06:05', 'Clínica da Cooperativa');
insert into consulta values( 4, 7, '2020-11-26 12:12:12', 'Clínica da Cooperativa');
insert into consulta values( 5, 8, '2020-11-27 12:12:12', 'Clínica da Cooperativa');

insert into consulta values( 5, 1, '2020-11-19 15:11:18', 'O Melhor Hospital que Existe');
insert into consulta values( 5, 3, '2020-11-20 13:10:11', 'O Melhor Hospital que Existe');
insert into consulta values( 6, 1, '2019-11-20 17:30:00', 'O Melhor Hospital que Existe');
insert into consulta values( 6, 2, '2020-11-20 12:06:05', 'Hospital Carérrimo');
insert into consulta values( 6, 9, '2020-11-23 14:15:00', 'SAMS');
insert into consulta values( 7, 5, '2020-11-24 10:15:00', 'SAMS');
insert into consulta values( 7, 6, '2020-11-25 12:06:05', 'Laboratório de São João');
insert into consulta values( 8, 7, '2020-11-26 12:12:12', 'Laboratório de São João');
insert into consulta values( 8, 8, '2020-11-27 12:12:12', 'Laboratório de São João');

insert into consulta values( 9, 1, '2020-11-27 15:11:18', 'Hospital Incrível');
insert into consulta values( 9, 3, '2020-11-27 13:10:11', 'Hospital Incrível');
insert into consulta values( 9, 1, '2020-11-30 17:30:00', 'Hospital Incrível');
insert into consulta values( 9, 2, '2020-11-30 12:06:05', 'Hospital Incrível');
insert into consulta values(10, 5, '2020-11-30 14:15:00', 'Laboratório Razoável');
insert into consulta values(10, 9, '2020-12-1 10:15:00', 'Laboratório Razoável');
insert into consulta values(11, 6, '2020-12-1 12:06:05', 'Laboratório Razoável');
insert into consulta values(11, 7, '2020-12-2 12:12:12', 'Laboratório Razoável');
insert into consulta values(11, 11, '2020-12-3 12:12:12', 'Laboratório Razoável');
insert into consulta values(18, 5, '2020-12-03 12:06:05', 'Laboratório de São João');



/*num_cedula, num_doente, dia_hora, substancia, quant*/
insert into prescricao values(11, 3, '2020-7-24 13:10:11', 'paracetamol',400);
insert into prescricao values(4, 2, '2020-9-3 12:06:05', 'xanax',600);
insert into prescricao values(11, 3, '2020-7-24 13:10:11', 'aspirina',2);
insert into prescricao values(11, 3, '2020-7-24 13:10:11', 'brufen',200);
insert into prescricao values(4, 2, '2020-9-3 12:06:05', 'aspirina',9);
insert into prescricao values(1, 1, '2019-01-17 15:11:18', 'aspirina',9);

insert into prescricao values(8, 1, '2019-5-31 17:30:00', 'brufen', 10);
insert into prescricao values(5, 5, '2019-01-01 10:15:00', 'valium', 60);
insert into prescricao values(2, 4, '2020-07-22 12:12:12', 'aspirina', 200); /*em arouca*/
insert into prescricao values(2, 5, '2020-07-06 12:12:12', 'aspirina', 200); /*em arouca*/

insert into prescricao values(9, 1, '2020-11-27 15:11:18', 'paracetamol',400);
insert into prescricao values(9, 2, '2020-11-30 12:06:05', 'zyrtec',600);
insert into prescricao values(10, 5, '2020-11-30 14:15:00', 'zyrtec', 50);
insert into prescricao values(11, 7, '2020-12-02 12:12:12', 'xanax',200);
insert into prescricao values(11, 11, '2020-12-03 12:12:12', 'xanax', 100);

/*num_analise, especialidade, num_cedula, num_doente, dia_hora, data_registo, nome, quant, inst*/
insert into analise values(1, 'oftalmologia', 8, 1, '2019-05-31 17:30:00', '2019-05-31 18:00:25', 'Glicémia', 15,'Laboratório Razoável');
insert into analise values(2, 'cardiologia', 11, 3, '2020-07-24 13:10:11', '2020-09-25 15:30:00', 'Leucócitos', 50, 'Isto Sim É Um Laboratório');
insert into analise values(3, 'neurologia', 4, 2, '2020-09-03 12:06:05', '2020-09-10 08:00:00', 'Leucócitos', 50,'Laboratório de São João');
insert into analise values(4, 'urologia', 5, 4, '2020-11-03 12:06:05', '2020-11-10 08:00:00', 'Leucócitos', 50,'Laboratório de São João');
insert into analise values(5, 'radiologia', 18, 5, '2020-12-03 12:06:05', '2020-12-10 08:00:00', 'Glicémia', 50,'Laboratório de São João');

/*num_venda, inst, data_registo, substancia, quant, preco*/
insert into vendaFarmacia values(1, 'Casa Farmacêutica', '2020-07-24 13:10:11','aspirina',200,15); /*em arouca*/
insert into vendaFarmacia values(2, 'Farmácia Nova Iorque', '2020-9-3 12:06:05','aspirina',200,15); /*em arouca*/
insert into vendaFarmacia values(3, 'Farmácia Decadente','2020-11-18 10:00:01','ben-u-ron',600,40);
insert into vendaFarmacia values(4, 'Farmácia Extremamente Decadente','2020-11-18 08:50:00', 'xanax',600,25);
insert into vendaFarmacia values(5, 'Farmácia de Jesus','2020-11-18 15:40:00', 'paracetamol',400,20);
insert into vendaFarmacia values(6, 'Farmácia de Jesus', '2020-11-18 12:06:05','brufen',200,25); /*em belmonte*/
insert into vendaFarmacia values(7, 'Casa Farmacêutica', '2020-07-22 12:12:12','aspirina',200,15); /*em arouca*/
insert into vendaFarmacia values(8, 'Farmácia Nova Iorque', '2020-07-06 12:12:12','aspirina',200,15); /*em arouca*/

insert into vendaFarmacia values(9, 'Farmácia Decadente', '2020-11-27 15:11:18', 'paracetamol',400, 20);
insert into vendaFarmacia values(10, 'Farmácia Decadente', '2020-11-30 12:06:05', 'zyrtec',600, 50);
insert into vendaFarmacia values(11, 'Farmácia Decadente', '2020-11-30 14:15:00', 'zyrtec', 50, 50);
insert into vendaFarmacia values(12, 'Farmácia Decadente', '2020-12-02 12:12:12', 'xanax', 200, 20);
insert into vendaFarmacia values(13, 'Farmácia Decadente', '2020-12-03 12:12:12', 'xanax', 100, 15);

insert into vendaFarmacia values(14, 'Farmácia Decadente', '2020-11-19 15:11:18', 'ben-u-ron',400, 20);
insert into vendaFarmacia values(15, 'Farmácia Decadente', '2020-11-19 12:06:05', 'ben-u-ron',600, 50);
insert into vendaFarmacia values(16, 'Casa Farmacêutica', '2020-11-19 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(17, 'Farmácia Decadente', '2020-11-20 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(18, 'Farmácia Decadente', '2020-11-20 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(19, 'Casa Farmacêutica', '2020-11-20 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(20, 'Farmácia Decadente', '2020-11-21 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(21, 'Farmácia Decadente', '2020-11-21 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(22, 'Casa Farmacêutica', '2020-11-21 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(23, 'Farmácia Decadente', '2020-11-22 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(24, 'Farmácia Decadente', '2020-11-22 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(25, 'Casa Farmacêutica', '2020-11-22 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(26, 'Farmácia Decadente', '2020-1-23 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(27, 'Farmácia Decadente', '2020-11-23 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(28, 'Casa Farmacêutica', '2020-11-23 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(29, 'Farmácia Decadente', '2020-11-24 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(30, 'Farmácia Decadente', '2020-11-24 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(31, 'Casa Farmacêutica', '2020-11-24 12:12:12', 'ben-u-ron', 100, 15);

insert into vendaFarmacia values(32, 'Farmácia Decadente', '2020-11-25 14:15:00', 'ben-u-ron', 50, 50);
insert into vendaFarmacia values(33, 'Farmácia Decadente', '2020-11-25 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(34, 'Casa Farmacêutica', '2020-11-25 12:12:12', 'ben-u-ron', 100, 15);

insert into vendaFarmacia values(35, 'Farmácia Decadente', '2020-11-26 14:15:00', 'ben-u-ron', 50, 50);
insert into vendaFarmacia values(36, 'Farmácia Decadente', '2020-11-26 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(37, 'Casa Farmacêutica', '2020-11-26 12:12:12', 'ben-u-ron', 100, 15);

insert into vendaFarmacia values(38, 'Farmácia Decadente', '2020-11-27 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(39, 'Farmácia Decadente', '2020-11-27 14:15:00', 'ben-u-ron', 50, 50);
insert into vendaFarmacia values(40, 'Casa Farmacêutica', '2020-11-27 12:12:12', 'ben-u-ron', 200, 20);

insert into vendaFarmacia values(41, 'Farmácia Decadente', '2020-11-28 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(42, 'Farmácia Decadente', '2020-11-28 14:15:00', 'ben-u-ron', 50, 50);
insert into vendaFarmacia values(43, 'Casa Farmacêutica', '2020-11-28 12:12:12', 'ben-u-ron', 200, 20);

insert into vendaFarmacia values(44, 'Farmácia Decadente', '2020-11-29 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(45, 'Farmácia Decadente', '2020-11-29 14:15:00', 'ben-u-ron', 50, 50);
insert into vendaFarmacia values(46, 'Casa Farmacêutica', '2020-11-29 12:12:12', 'ben-u-ron', 200, 20);

insert into vendaFarmacia values(47, 'Farmácia Decadente', '2020-11-30 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(48, 'Farmácia Decadente', '2020-11-30 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(49, 'Casa Farmacêutica', '2020-11-30 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(50, 'Farmácia Decadente', '2020-12-01 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(51, 'Farmácia Decadente', '2020-12-01 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(52, 'Casa Farmacêutica', '2020-12-01 14:15:00', 'ben-u-ron', 50, 50);

insert into vendaFarmacia values(53, 'Farmácia Decadente', '2020-12-02 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(54, 'Farmácia Decadente', '2020-12-02 12:12:12', 'ben-u-ron', 100, 15);
insert into vendaFarmacia values(55, 'Casa Farmacêutica', '2020-12-02 12:12:12', 'ben-u-ron', 100, 15);

insert into vendaFarmacia values(56, 'Farmácia Decadente', '2020-12-03 14:15:00', 'ben-u-ron', 50, 50);
insert into vendaFarmacia values(57, 'Farmácia Decadente', '2020-12-03 12:12:12', 'ben-u-ron', 200, 20);
insert into vendaFarmacia values(58, 'Casa Farmacêutica', '2020-12-03 12:12:12', 'ben-u-ron', 100, 15);



/*num_cedula, num_doente, data, subs, num_venda*/
insert into prescricaoVenda values(11, 3, '2020-07-24 13:10:11', 'paracetamol', 4);
insert into prescricaoVenda values(4, 2, '2020-09-03 12:06:05', 'xanax', 5);
insert into prescricaoVenda values(11, 3, '2020-07-24 13:10:11', 'aspirina', 1); /*em arouca*/
insert into prescricaoVenda values(4, 2, '2020-9-3 12:06:05', 'aspirina', 2); /*em arouca*/
insert into prescricaoVenda values(2, 4, '2020-07-22 12:12:12', 'aspirina', 7); /*em arouca*/
insert into prescricaoVenda values(2, 5, '2020-07-06 12:12:12', 'aspirina', 8); /*em arouca*/

insert into prescricaoVenda values(9, 1, '2020-11-27 15:11:18', 'paracetamol', 9);
insert into prescricaoVenda values(9, 2, '2020-11-30 12:06:05', 'zyrtec', 10);
insert into prescricaoVenda values(10, 5, '2020-11-30 14:15:00', 'zyrtec', 11);
insert into prescricaoVenda values(11, 7, '2020-12-02 12:12:12', 'xanax', 12);
insert into prescricaoVenda values(11, 11, '2020-12-03 12:12:12', 'xanax', 12);
